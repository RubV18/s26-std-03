from futurdata_pptx.gui import main

main()
