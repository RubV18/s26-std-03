# Comparison with the Initial Team Prototype

The original prototype had a clear starting structure but relied on this expression:

```python
current_source = guide.product.name if step.index == 1 or not guide.steps[step.index - 2].continues_as else guide.steps[step.index - 2].continues_as.name
```

That expression was removed because it assumes step indexes equal list positions and that every operation continues from the immediately previous operation. It assigns the product root to Step 9 and Step 11 in the supplied JSON even though those operations begin separate branches.

The complete implementation replaces it with:

```python
source, method = document.source_for_step(position)
```

Resolution order:

1. Use an explicit `step.source` object when available.
2. Use the product only for the first operation.
3. Use the previous `continues_as` only when the previous operation actually continues.
4. When the previous branch ended, report `source not specified in JSON`.

Additional changes:

- no `step.index - 2` list indexing;
- complete BoM pagination;
- outputs and continuation components;
- weights, materials, colors, quality and destination;
- step/action tools and safety notices;
- local and data-URI images;
- product and per-step mass validation;
- precise warning locations;
- configurable range, limit and grouping;
- GUI and CLI;
- generic exporter interface and registry;
- settings save/resume;
- automated tests;
- safe output path and file-open error handling.
